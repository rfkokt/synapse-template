import { type InputHTMLAttributes } from 'react';
export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
}
export declare const Input: any;
//# sourceMappingURL=Input.d.ts.map
